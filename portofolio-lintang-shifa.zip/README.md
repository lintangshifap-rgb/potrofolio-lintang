# Portofolio Lintang Shifa Prameswari, A.Md.Kep

Paket website portofolio siap deploy ke layanan hosting publik seperti:
- GitHub Pages
- Netlify (Tinggal drag & drop folder ini ke Netlify Drop)
- Vercel
- Hosting cPanel / Domainesia / Niagahoster

## Struktur Folder
- `index.html` : Halaman utama website portofolio
- `assets/images/` : Seluruh berkas dokumentasi praktik klinis dan foto profil

## Cara Deploy ke Netlify (Paling Mudah & Gratis):
1. Buka https://app.netlify.com/drop
2. Ekstrak file zip ini terlebih dahulu.
3. Tarik (drag & drop) folder hasil ekstrak ke halaman Netlify.
4. Website Anda langsung online dalam hitungan detik!
